Rufus macOS 4.10-macOS

Installation:
1. Copy rufus-macos from bin/ to /usr/local/bin/ (requires sudo)
2. Make sure /usr/local/bin is in your PATH

Usage:
  rufus-macos -l              # List USB devices  
  rufus-macos -d disk2 -f FAT32  # Format device

For more information, see docs/README_macOS.md

WARNING: This software can erase data on your drives. Use with caution!
